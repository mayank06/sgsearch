define(['knockout'], function(ko) {
	return function FeedbackPopup() {
		var self = this;
		self.pageId = "FeedbackPopup";
		var db = openDatabase('RDPApp', '1.0', 'Test DB', 2 * 1024 * 1024);
		var userProfile;
		var NotificationData;
		self.actionBySiteTeam = ko.observable();
		self.additionalInfo = ko.observable();
		self.issueStatus = ko.observable();
		var actionBySiteTeam = '';
		var additionalInfo = '';
		var issueStatus = '';
		self.init = function(userProfileFromNotifications, dataFromNotifications) {
			currentPageId = self.pageId;
			userProfile = userProfileFromNotifications;
			NotificationData = dataFromNotifications;
			console.log(userProfile);
			console.log(NotificationData);
			self.clickYesIssue();
			self.clickYesforRemote();
		};

		self.createFeedback = function() {
			$(".finalComment  textarea").val('');
			hideFeedbackPopup();
			actionBySiteTeam = (self.actionBySiteTeam());
			additionalInfo = (self.additionalInfo());
			console.log(actionBySiteTeam);
			console.log(additionalInfo);

			if (self.actionBySiteTeam() !== "") {
				if (self.additionalInfo() !== "") {
					console.log("valid field of feedback");
					self.postWebService1();
				} else
					console.log("This field can not be null");
			} else
				alert("This field can not be null");

		};
		self.postWebService1 = function() {
			feedback = ( {
				sender : userProfile.email,
				title : NotificationData.title,
				engineSerial : NotificationData.engineSerial,
				organization : NotificationData.organization,
				name : "null",
				addEmail : "null",
				contact : "null",
				issueStatus : issueStatus,
				rmTeamStatus : rmTeamStatus,
				rmTeamIssueDesc : "null",
				actionBySiteTeam : actionBySiteTeam,
				additionalInfo : additionalInfo,
			});
			var jsonfeedback = JSON.stringify(feedback);
			console.log(feedback);
			console.log(jsonfeedback);

			xhr = $.ajax({
				type : "POST",

				url : webServiceURL_feedBack_mail,
				data : jsonfeedback,
				headers : {
					"Content-Type" : "application/json",
					"Accept" : "application/json"
				},
				// contentType : "application/json; charset=utf-8",
				// dataType : "json",
				success : function(data) {
					console.log(data);
				},
				failure : function(errMsg) {
					alert(errMsg);
				},
				complete : function(response) {
					console.log(response.responseText);
					alert(response.responseText);
					hideFeedbackPopup();
				}
			});
			console.log(xhr);

		};

		self.clickYesIssue = function() {
			console.log("clicked yes");
			$("#issueRadioYes").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioNo").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');
			issueStatus = "Yes";
			console.log(issueStatus);

		};
		self.clickNoIssue = function() {
			console.log("clicked no");
			$("#issueRadioNo").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioYes").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');
			issueStatus = "No";

		};
		self.clickYesforRemote = function() {
			console.log("clicked yes");
			$("#issueRadioYesforRemote").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioNoforRemote").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');

			rmTeamStatus = "Yes";
		};
		self.clickNoforRemote = function() {
			console.log("clicked no");
			$("#issueRadioNoforRemote").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioYesforRemote").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');

			rmTeamStatus = "No";

		};

		self.cancelFeedback = function() {
			$(".finalComment  textarea").val('');
			$(".SubBoxHeadFNotes textarea").val('');
			hideFeedbackPopup();
		};

	};
});
