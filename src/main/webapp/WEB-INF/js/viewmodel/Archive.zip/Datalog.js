define(['knockout'], function(ko) {
	return function Datalog() {
		var self = this;
		self.pageId = "Datalog";
		var db = openDatabase('RDPApp', '1.0', 'Test DB', 2 * 1024 * 1024);
		document.getElementById("gesn-no-list").style.display = "none";
		self.upTimeHours = ko.observable();
		self.upTimeMinutes = ko.observable();
		self.upTimeNotes = ko.observable();
		self.idleTimeHours = ko.observable();
		self.idleTimeMinutes = ko.observable();
		self.idleTimeNotes = ko.observable();
		self.plannedOutageHrs = ko.observable();
		self.plannedOutageMinutes = ko.observable();
		self.plannedOutageNotes = ko.observable();
		self.unplannedOutageHrs = ko.observable();
		self.unplannedOutageMinutes = ko.observable();
		self.unplannedOutageNotes = ko.observable();
		self.dataLogNotes = ko.observable();
		self.pickedGesnNo = ko.observable();
		self.pickedDate = ko.observable();
		self.dataLogsList = ko.observableArray();
		var dataLogsListTempData = [];
		self.dataLogsHistoryList = ko.observableArray();
		self.valueOptions = ko.observableArray(['Percentage', 'Value']);
		self.selectedChoice = ko.observable();
		self.gesnList = ko.observableArray();

		var datalogFromDate;
		var historyFromDate;
		var datalogToDate;
		var historyToDate;

		// var autoFillGesn;
		//for static datalog
		var pickedGesnNo = '';
		var pickedDate = '';
		//for static datalog
		var todayDate = '';
		var todayDateThreeLetterMonthFormat = '';
		var currentTime = '';
		var currentGesn = '';
		var upTimeHours;
		var upTimeMinutes;
		var upTimeNotes = '';
		var idleTimeHours;
		var idleTimeMinutes;
		var idleTimeNotes = '';
		var plannedOutageHrs;
		var plannedOutageMinutes;
		var plannedOutageNotes = '';
		var unplannedOutageHrs;
		var unplannedOutageMinutes;
		var unplannedOutageNotes = '';
		var dataLogNotes = '';
		var userProfile;
		var gesnArrayGlobal;
		var datalog = new Object();
		self.init = function(gesnArray, userProfileFromGlobalMenu) {
			currentPageId = self.pageId;
			userProfile = userProfileFromGlobalMenu;
			var toDayDate = self.currDate();
			$(".date-select").val('');
			// self.currDateToDate(toDayDate);
			datePickerFunctions();
			datalogFromDate = '';
			historyFromDate = '';
			datalogToDate = '';
			historyToDate = '';
			autoFillGesn(gesnArray);
			gesnArrayGlobal = [];
			for (var i = 0; i < gesnArray.length; i++)
				gesnArrayGlobal.push(gesnArray[i].globalSerialNumber);
			// self.getDataForDatalogFromWebService();
			// self.getDataForHistoryFromWebService();
			self.allUnitsTab();
		};

		//Gesn Auto fill functionality----------------------------------------------start----------
		//-----------------------------------------------------------------------------------------
		autoFillGesn = function(gesnArray) {
			console.log(gesnArray);
			self.gesnList(gesnArray);
			$('html').click(function() {
				$('#gesn-no-list').hide();
				$('.gm-gesn').hide();
			});

		};
		self.dropdownGesnDiv = function(data, event) {
			console.log("in dropdown gesn div");
			console.log("hello");
			console.log(event);
			console.log(event.currentTarget.nextElementSibling);
			var x = event.currentTarget.nextElementSibling.style.display;
			console.log(x);
			if (x == "none") {
				event.currentTarget.nextElementSibling.style.display = "block";
			} else if (x == "block") {
				event.currentTarget.nextElementSibling.style.display = "none";
			}
		};

		self.searchGesn = function(data, event) {
			document.getElementById("gesn-no-list").style.display = "block";
			var target = event.target;
			if ( typeof event !== "undefined") {
				var KeyID = event.keyCode;
				var userString1 = $("#gesn-tag").val().trim();
				var userString = userString1.toUpperCase();
				console.log("userString");
				if (KeyID === 8) {
					$(".gm-gesn:contains(" + userString + ")").show();
				} else {
					$(".gm-gesn:contains(" + userString + ")").show();
					$(".gm-gesn:not(:contains(" + userString + "))").hide();
				}
			}

		};

		self.clickedGesn = function(data, event) {
			console.log("Inside clickedElement");
			console.log(data);
			self.pickedGesnNo(data.globalSerialNumber);
			console.log(self.pickedGesnNo());
			// $("#gesn-tag").val(data);
			document.getElementById("gesn-no-list").style.display = "none";
		};

		self.onClickGesn = function(data, event) {
			console.log("in oncliockgesn");
			console.log(event);
			$('#gesn-no-list').show();
			$('.gm-gesn').show();
			event.stopPropagation();
		};
		//---------------------------------------------------------------------------------------
		//Gesn Auto fill functionality----------------------------------------------end----------

		self.allUnitsTab = function() {
			self.resetDatalog();
			$("#all-units").show();
			$("#all-units-tab").css('background-color', '#4e79d1');
			$("#all-units-tab").css('color', 'white');
			self.getDataForDatalogFromWebService();
//			if (navigationStatus.Datalog == "Active") {
//				clearAllIntervals();
//				dataLogWebserviceCallAll = setInterval(self.getDataForDatalogFromWebService, 30000);
//			}
			// self.getDataForHistoryFromWebService();
		};
		self.addDatalogTab = function() {
			self.resetDatalog();
			$("#add-datalog").show();
			$("#add-datalog-tab").css('background-color', '#4e79d1');
			$("#add-datalog-tab").css('color', 'white');
			clearAllIntervals();
		};
		self.historicalNotesTab = function() {
			self.resetDatalog();
			$("#historical-notes").show();
			$("#historical-notes-tab").css('color', 'white');
			$("#historical-notes-tab").css('background-color', '#4e79d1');
			showLoader();
			self.getDataForHistoryFromWebService();
			// if (navigationStatus.Datalog == "Active") {
			// clearAllIntervals();
			// dataLogWebserviceCallHistory = setInterval(self.getDataForHistoryFromWebService, 30000);
			// }
		};
		self.resetDatalog = function() {
			$(".datalog-container").hide();
			$(".datalog-tabs").css('color', '#4e79d1');
			$(".datalog-tabs").css('background-color', 'white');
		};
		// self.UiAutoComplete = function(gesnArray) {
		// var gesnArray2 = [];
		// for (var i = 0; i < gesnArray.length; i++)
		// gesnArray2.push(gesnArray[i].globalSerialNumber);
		// console.log(gesnArray2);
		// autoFillGesn = $("#gesn-tag").autocomplete({
		// source : gesnArray2,
		// change : function(event, ui) {
		// // console.log(event);
		// console.log(ui.item.value);
		// if (ui.item.value != null)
		// self.pickedGesnNo(ui.item.value);
		// }
		// });
		// };
		self.openDataLogPopUpFromDatalog = function(data, event) {
			console.log("clicked data log");
			console.log(data);
			config.bindViewModel(app.DatalogPopup, function(viewModel) {
				app.DatalogPopup.vModel.init(data.gesn, userProfile);
				showDataLogPopUp();
			});
		};

		self.collapseExpandDatalog = function(data, event) {
			console.log(data);
			// console.log(event);
			// console.log(event.target);
			// console.log(event.target.id);
			// console.log(event.currentTarget.nextSibling.parentElement);
			var x = event.currentTarget;
			if (x.style.height == "100px") {
				self.defaultExpandCollapseDatalog();
				x.style.height = "200px";
				x.children[2].style.backgroundImage = 'url("../img/Notification/X-Notification-up-dropdown-arrow.png")';
			} else {
				self.defaultExpandCollapseDatalog();
				x.style.height = "100px";
				x.children[2].style.backgroundImage = 'url("../img/Notification/X-Notification-down-dropdown-arrow.png")';
			}

		};

		self.defaultExpandCollapseDatalog = function() {
			$(".datalogtile-historical").css('height', '100px');
			$(".datalogtile-historical").css('overflow', 'hidden');
		};

		self.currDate = function() {
			var toDay = new Date();
			var currMonth = convertNoToMonth(toDay.getMonth());
			var cuurDay = ("0" + toDay.getDate()).slice(-2);
			todayDate = toDay.getDate() + " " + currMonth + " " + toDay.getFullYear();
			todayDateThreeLetterMonthFormat = cuurDay + "-" + currMonth.substring(0, 3) + "-" + toDay.getFullYear();
			console.log(todayDateThreeLetterMonthFormat);
			currentTime = toDay.getHours() + ":" + toDay.getMinutes() + ":" + toDay.getSeconds();
			return todayDateThreeLetterMonthFormat;
		};
		self.getDataForHistoryFromWebService = function() {
			console.log("in history");
			console.log(historyFromDate);
			// var startDate = historyFromDate;
			if (historyFromDate == '' || historyToDate == '') {
				console.log("not selected");
				var urlHeader = '';
				var startDate = '';
				var endDate = '';
			} else {
				console.log("selected");
				var startDate = historyFromDate;
				console.log("selected	" + startDate);
				var endDate = historyToDate;
				var urlHeader = "?startDate=" + startDate + "&endDate=" + endDate;
			}
			if (self.selectedChoice() == "Value")
				var type = "value";
			else
				var type = "percentage";
			console.log(startDate + "    " + endDate + "      " + type);
			// showLoader();
			$.ajax({
				url : webServiceURL_getHistoricalNotes + urlHeader,
				// url : "http://3.209.197.8:8084/dpsapp/resources/logNotes?startDate=" + startDate + "&endDate=" + endDate,
				// url : "http://3.209.197.8:8084/dpsapp/resources/datalogs?startDate=" + startDate + "&endDate=" + endDate + "&type=value",
				headers : {
					"Content-Type" : "application/json"
				},
				success : function(data) {
					console.log(data);
                   var len = data.historicalNotes.length;
                   if(len == 0) {
                   hideLoader();
                   } else {
					var newhistoricalNotes = [];

					for (var j = 0; j < len; j++) {
						for (var i = 0; i < gesnArrayGlobal.length; i++) {
							if (gesnArrayGlobal[i] == data.historicalNotes[j].gesn)
								newhistoricalNotes.push(data.historicalNotes[j]);
						}
					}
					console.log(newhistoricalNotes);
					self.dataLogsHistoryList(newhistoricalNotes);
					hideLoader();
                   };
				},
				error : function(errMsg) {
					alert(errMsg);
				},
				complete : function(response) {
					console.log(response.status);
				}
			});
		};
		self.getDataForDatalogFromWebService = function() {
			// var startDate = datalogFromDate;
			var startDate = '';
			var endDate = '';
			if (datalogFromDate == '' || datalogToDate == '') {
				console.log("not selected");
				startDate = '';
				endDate = '';
			} else {
				console.log("selected");
				startDate = datalogFromDate;
				console.log("selected	" + startDate);
				endDate = datalogToDate;
			}
			console.log(startDate + "    " + endDate);
			// if (startDate > self.currDate()) {
			// hideLoader();
			// alert("Exceded current date");
			// } else {
			// showLoader();
			$.ajax({
				url : webServiceURL_getDataLogs + "?startDate=" + startDate + "&endDate=" + endDate + "&type=value",
				headers : {
					"Content-Type" : "application/json"
				},
				success : function(data) {
					console.log(data);
					console.log(gesnArrayGlobal);
                   var len = data.dataLogsList.length;
                   if(len == 0) {
                   hideLoader();
                   } else {
					var newdataloglist = [];

					for (var j = 0; j < len; j++) {
						for (var i = 0; i < gesnArrayGlobal.length; i++) {
							if (gesnArrayGlobal[i] == data.dataLogsList[j].gesn)
								newdataloglist.push(data.dataLogsList[j]);
						}
					}
					console.log(newdataloglist);
					dataLogsListTempData = newdataloglist;
					// dataLogsListTempData = data.dataLogsList;
					if (self.selectedChoice() == "Value")
						self.selectedChoiceValue();
					else
						self.selectedChoicePercentage();
					hideLoader();
                   };
				},
				error : function(errMsg) {
					alert(errMsg);
				},
				complete : function(response) {
					console.log(response.status);
				}
			});
			// }

		};
		self.changedDropDown = function(data, event) {
			console.log(self.selectedChoice());
			var selectedChoice = self.selectedChoice();
			var temp = self.dataLogsList();
			if (selectedChoice == "Value") {
				self.selectedChoiceValue();
			} else {
				self.selectedChoicePercentage();
			}
			hideLoader();
		};
		self.selectedChoiceValue = function() {
			var datalogtemp = [];
			for ( i = 0; i < dataLogsListTempData.length; i++) {
				var a = Number(dataLogsListTempData[i].upTime);
				var b = Number(dataLogsListTempData[i].idleTime);
				var c = Number(dataLogsListTempData[i].plannedOutageTime);
				var d = Number(dataLogsListTempData[i].unPlannedOutageTime);
				datalogtemp.push({
					gesn : dataLogsListTempData[i].gesn,
					logDate : dataLogsListTempData[i].logDate,
					upTimePercent : (Math.round(a * 10000 / (a + b + c + d)) / 100) + "%",
					idleTimePercent : (Math.round(b * 10000 / (a + b + c + d)) / 100) + "%",
					plannedOutageTimePercent : (Math.round(c * 10000 / (a + b + c + d)) / 100) + "%",
					unPlannedOutageTimePercent : (Math.round(d * 10000 / (a + b + c + d)) / 100) + "%",
					upTimeVal : a,
					idleTimeVal : b,
					plannedOutageTimeVal : c,
					unPlannedOutageTimeVal : d
				});
			}
			self.dataLogsList(datalogtemp);
			self.selectedChoice("Value");
		};
		self.selectedChoicePercentage = function() {
			var datalogtemp = [];
			for ( i = 0; i < dataLogsListTempData.length; i++) {
				var a = Number(dataLogsListTempData[i].upTime);
				var b = Number(dataLogsListTempData[i].idleTime);
				var c = Number(dataLogsListTempData[i].plannedOutageTime);
				var d = Number(dataLogsListTempData[i].unPlannedOutageTime);
				datalogtemp.push({
					gesn : dataLogsListTempData[i].gesn,
					logDate : dataLogsListTempData[i].logDate,
					upTimePercent : (Math.round(a * 10000 / (a + b + c + d)) / 100) + "%",
					idleTimePercent : (Math.round(b * 10000 / (a + b + c + d)) / 100) + "%",
					plannedOutageTimePercent : (Math.round(c * 10000 / (a + b + c + d)) / 100) + "%",
					unPlannedOutageTimePercent : (Math.round(d * 10000 / (a + b + c + d)) / 100) + "%",
					upTimeVal : (Math.round(a * 10000 / (a + b + c + d)) / 100) + "%",
					idleTimeVal : (Math.round(b * 10000 / (a + b + c + d)) / 100) + "%",
					plannedOutageTimeVal : (Math.round(c * 10000 / (a + b + c + d)) / 100) + "%",
					unPlannedOutageTimeVal : (Math.round(d * 10000 / (a + b + c + d)) / 100) + "%"
				});
			}
			self.dataLogsList(datalogtemp);
			self.selectedChoice("Percentage");
		};
		self.checkTime = function(hours, minutes) {
			var hoursNo = Number(hours);
			var minutesNo = Number(minutes);
			console.log(hoursNo);
			console.log(minutesNo);
			var temp1 = hoursNo * 10 / 10;
			var temp2 = minutesNo * 10 / 10;
			var hoursStg = String(temp1);
			var minuteStg = String(temp2);
			if (hours > 24 || hours < 0 || minutes < 0 || minutes > 59 || hours == undefined || minutes == undefined || hours != hoursStg || minutes != minuteStg || hours % 1 != 0 || minutes % 1 != 0)
				return false;
			else
				return true;
		};
		self.totalTimeValidation = function() {
			var totalTimeMinutes = ((upTimeHours * 60) + upTimeMinutes) + (idleTimeHours * 60) + idleTimeMinutes + (plannedOutageHrs * 60) + plannedOutageMinutes + (unplannedOutageHrs * 60) + unplannedOutageMinutes;
			totalTimeMinutes = totalTimeMinutes;
			var actualTime = 24 * 60;
			// console.log(totalTimeMinutes);
			// console.log(actualTime);
			if (totalTimeMinutes > actualTime)

				alert("Log Hours exceeds 24 hours");
			if (totalTimeMinutes < actualTime)

				alert("Log Hours less than 24 hours");
			if (totalTimeMinutes != actualTime)
				return false;
			else
				return true;
		};

		self.createDataLog = function() {
			$(".SubBoxHeadFHP input").css('background-color', '#EDEDED');
			upTimeHours = Number(self.upTimeHours());
			upTimeMinutes = Number(self.upTimeMinutes());
			upTimeNotes = self.upTimeNotes();
			idleTimeHours = Number(self.idleTimeHours());
			idleTimeMinutes = Number(self.idleTimeMinutes());
			idleTimeNotes = self.idleTimeNotes();
			plannedOutageHrs = Number(self.plannedOutageHrs());
			plannedOutageMinutes = Number(self.plannedOutageMinutes());
			plannedOutageNotes = self.plannedOutageNotes();
			unplannedOutageHrs = Number(self.unplannedOutageHrs());
			unplannedOutageMinutes = Number(self.unplannedOutageMinutes());
			unplannedOutageNotes = self.unplannedOutageNotes();
			dataLogNotes = self.dataLogNotes();
			// pickedGesnNo = autoFillGesn.val();
			// self.pickedGesnNo(pickedGesnNo);
			pickedGesnNo = self.pickedGesnNo();
			pickedDate = self.pickedDate();
			if (self.checkTime(upTimeHours, upTimeMinutes)) {
				if (self.checkTime(idleTimeHours, idleTimeMinutes)) {
					if (self.checkTime(plannedOutageHrs, plannedOutageMinutes)) {
						if (self.checkTime(unplannedOutageHrs, unplannedOutageMinutes)) {
							if (self.totalTimeValidation()) {
								console.log("valid");
								self.postWebService();
							} else
								console.log("total should be 24hours");
						} else
							alert("Please enter valid data");
					} else
						alert("Please enter valid data");
				} else
					alert("Please enter valid data");
			} else
				alert("Please enter valid data");

			if (self.checkTime(upTimeHours, upTimeMinutes) == false) {
				$("#uptimeHr").css('background-color', '#F1C5C5');
				$("#uptimeMn").css('background-color', '#F1C5C5');
			}
			if (self.checkTime(idleTimeHours, idleTimeMinutes) == false) {
				$("#idletimeHr").css('background-color', '#F1C5C5');
				$("#idletimeMn").css('background-color', '#F1C5C5');
			}
			if (self.checkTime(plannedOutageHrs, plannedOutageMinutes) == false) {
				$("#plannedHr").css('background-color', '#F1C5C5');
				$("#plannedMn").css('background-color', '#F1C5C5');
			}
			if (self.checkTime(unplannedOutageHrs, unplannedOutageMinutes) == false) {
				$("#unplannedHr").css('background-color', '#F1C5C5');
				$("#unplannedMn").css('background-color', '#F1C5C5');
			}
		};

		self.cancelDataLog = function() {
			hideDataLogPopUp();
			pickedDate = self.pickedDate();
			console.log(pickedDate);
			console.log(self.pickedGesnNo());
			// pickedGesnNo = autoFillGesn.val();
			// upTimeHours = self.upTimeHours();
			// upTimeMinutes = self.upTimeMinutes();
			// console.log(upTimeHours);
			// console.log(upTimeMinutes);
			// self.createDataLog();
			console.log(self.checkTime(upTimeHours, upTimeMinutes));
			console.log(self.checkTime(idleTimeHours, idleTimeMinutes));
			console.log(self.checkTime(plannedOutageHrs, plannedOutageMinutes));
			console.log(self.checkTime(unplannedOutageHrs, unplannedOutageMinutes));
			$(".SubBoxHeadFHP input").val('');
			$(".SubBoxHeadFNotes textarea").val('');
			$(".finalComment textarea").val('');
			$("#datalog-date-select").val('');
			$("#gesn-tag").val('');

			$(".SubBoxHeadFHP input").css('background-color', '#EDEDED');
			// self.pickedGesnNo(pickedGesnNo);
		};
		self.postWebService = function() {
			showLoader();
			datalog = ( {
				dataLog : {
					gesn : pickedGesnNo,
					logDate : pickedDate,
					// logDate : "31-Dec-2015",
					// systemTime : currentTime,
					upTimehours : upTimeHours,
					upTimeminutes : upTimeMinutes,
					upTimenotes : upTimeNotes,
					idleTimehours : idleTimeHours,
					idleTimeminutes : idleTimeMinutes,
					idleTimenotes : idleTimeNotes,
					plannedOutagehours : plannedOutageHrs,
					plannedOutageminutes : plannedOutageMinutes,
					plannedOutagenotes : plannedOutageNotes,
					unplannedOutagehours : unplannedOutageHrs,
					unplannedOutageminutes : unplannedOutageMinutes,
					unplannedOutagenotes : unplannedOutageNotes,
					dataLogNotes : dataLogNotes
				}
			});
			var jsonDatalog = JSON.stringify(datalog);
			console.log(datalog);
			console.log(jsonDatalog);
			xhr = $.ajax({
				type : "POST",
				url : webServiceURL_createDatalog,
				data : jsonDatalog,
				headers : {
					"Content-Type" : "application/json",
					"Accept" : "application/json"
				},
				// contentType : "application/json; charset=utf-8",
				// dataType : "json",
				success : function(data) {
					console.log(data);
				},
				failure : function(errMsg) {
					// alert(errMsg);
				},
				complete : function(response) {
					console.log(response);
					// alert(response.responseText);
					// hideDataLogPopUp();
					console.log(response.responseText);
					console.log(response.status);
					hideLoader();
					if (response.status == 200 && response.readyState == 4) {
						alert(response.responseText);
						hideDataLogPopUp();
					} else {
						alert("Please try after some time");
					}
				}
			});
			console.log(xhr);
		};

		self.searchDatalog = function(data, event) {
			var target = event.target;
			//$('input').removeClass('iDebrief-search-input-magnifier');
			if ( typeof event !== "undefined") {
				var KeyID = event.keyCode;
				var userString = $("#search-machine-datalog").val().trim();
				userString = userString.toUpperCase();
				console.log("userString");
				if (KeyID === 8) {
					$(".datalogtile:contains(" + userString + ")").show();
					$(".datalogtile-historical:contains(" + userString + ")").show();
				} else {
					$(".datalogtile:contains(" + userString + ")").show();
					$(".datalogtile:not(:contains(" + userString + "))").hide();
					$(".datalogtile-historical:contains(" + userString + ")").show();
					$(".datalogtile-historical:not(:contains(" + userString + "))").hide();
				};
			};

		};

		datePickerFunctions = function() {
			$("#allunits-datepicker").datepicker({
				dateFormat : 'dd-M-yy',
				monthNamesShort : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				onSelect : function(fromDate) {
					console.log(fromDate);
					fromDate = new Date(fromDate) / 1000;
					console.log(datalogToDate);
					datalogFromDate = fromDate;
					if (datalogToDate == '') {
					} else {
						showLoader();
						self.getDataForDatalogFromWebService();
					}
				}
			});
			$("#todate-datepicker").datepicker({
				dateFormat : 'dd-M-yy',
				monthNamesShort : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				onSelect : function(toDate) {
					console.log(datalogFromDate);
					toDate = new Date(toDate) / 1000;
					console.log(toDate);
					datalogToDate = toDate;
					showLoader();
					if (datalogFromDate == '') {
					} else {
						showLoader();
						self.getDataForDatalogFromWebService();
					}
				}
			});

			$("#history-datepicker").datepicker({
				dateFormat : 'dd-M-yy',
				monthNamesShort : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				onSelect : function(fromDate) {
					fromDate = new Date(historyFromDate) / 1000;
					console.log(fromDate);
					historyFromDate = fromDate;
					if (historyToDate == '') {
					} else {
						showLoader();
						self.getDataForHistoryFromWebService();
					}
				}
			});

			$("#todate-datepicker-history").datepicker({
				dateFormat : 'dd-M-yy',
				monthNamesShort : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				onSelect : function(toDate) {
					console.log(historyFromDate);
					toDate = new Date(historyFromDate) / 1000;
					console.log(toDate);
					historyToDate = toDate;
					if (historyFromDate == '') {
					} else {
						showLoader();
						self.getDataForHistoryFromWebService();
					}
				}
			});

			$("#datalog-date-select").datepicker({
				dateFormat : 'dd-M-yy',
				monthNamesShort : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
			});
		};

	};
});
