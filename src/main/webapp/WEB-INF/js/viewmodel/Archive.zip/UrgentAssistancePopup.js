define(['knockout'], function(ko) {
	return function UrgentAssistancePopup() {
		var self = this;
		self.pageId = "UrgentAssistancePopup";
		var db = openDatabase('RDPApp', '1.0', 'Test DB', 2 * 1024 * 1024);
		var userProfile;
		var NotificationData;
		self.name = ko.observable();
		self.addEmail = ko.observable();
		self.contact = ko.observable();
		self.rmTeamIssueDesc = ko.observable();
		self.actionBySiteTeam = ko.observable();
		self.additionalInfo = ko.observable();

		var name = '';
		var addEmail = '';
		var contact = '';
		var rmTeamIssueDesc = '';
		var actionBySiteTeam = '';
		var additionalInfo = '';

		self.init = function(userProfileFromNotifications, dataFromNotifications) {
			currentPageId = self.pageId;
			userProfile = userProfileFromNotifications;
			NotificationData = dataFromNotifications;
			self.clickYesforDecRemote();
		};
		self.createUrgentAssistance = function() {
			$(".finalComment  textarea").val('');
			hideUrgentAssistancePopup();
			name = (self.name());
			addEmail = (self.addEmail());
			contact = (self.contact());
			rmTeamIssueDesc = (self.rmTeamIssueDesc());
			actionBySiteTeam = (self.actionBySiteTeam());
			additionalInfo = (self.additionalInfo());
			console.log(name);
			console.log(addEmail);
			console.log(contact);
			console.log(rmTeamIssueDesc);
			console.log(actionBySiteTeam);
			console.log(additionalInfo);

			if (self.name() !== "") {
				if (self.contact() !== "") {
					if (self.rmTeamIssueDesc() !== "") {
						if (self.actionBySiteTeam() !== "") {
							if (self.additionalInfo() !== "") {
								console.log("valid field of feedback");
								self.postWebService2();
							} else
								alert("This field can not be null");
						} else
							alert("This field can not be null");
					} else
						alert("This field can not be null");
				} else
					alert("This field can not be null");
			} else
				alert("select option");
		};

		self.postWebService2 = function() {
			urgent = ( {
				sender : userProfile.email,
				title : NotificationData.title,
				engineSerial : NotificationData.engineSerial,
				organization : NotificationData.organization,
				name : name,
				addEmail : addEmail,
				contact : contact,
				issueStatus : null,
				rmTeamStatus : rmTeamStatus,
				rmTeamIssueDesc : rmTeamIssueDesc,
				actionBySiteTeam : actionBySiteTeam,
				additionalInfo : additionalInfo,
			});
			var jsonurgent = JSON.stringify(urgent);
			console.log(urgent);
			console.log(jsonurgent);
			xhr = $.ajax({
				type : "POST",

				url : webServiceURL_uegent_mail,
				data : jsonurgent,
				headers : {
					"Content-Type" : "application/json",
					"Accept" : "application/json"
				},
				// contentType : "application/json; charset=utf-8",
				// dataType : "json",
				success : function(data) {
					console.log(data);
				},
				failure : function(errMsg) {
					alert(errMsg);
				},
				complete : function(response) {
					console.log(response.responseText);
					alert(response.responseText);
					hideUrgentAssistancePopup();
				}
			});
			console.log(xhr);
		};

		self.clickYesforDecRemote = function() {
			console.log("clicked yes");
			$("#issueRadioYesforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioNoforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');

			rmTeamStatus = "Yes";
		};
		self.clickNoforDecRemote = function() {
			console.log("clicked no");
			$("#issueRadioNoforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioYesforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');

			rmTeamStatus = "No";

		};

		self.cancelUrgentAssistance = function() {
			hideUrgentAssistancePopup();
			$(".name  input").val('');
			$(".email  input").val('');
			$(".phone  input").val('');
			$(".finalComment  textarea").val('');
			console.log("urgent");
		};
	};
});
