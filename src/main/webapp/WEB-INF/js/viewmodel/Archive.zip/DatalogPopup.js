define(['knockout'], function(ko) {
	return function DatalogPopup() {
		var self = this;
		self.pageId = "DatalogPopup";
		var db = openDatabase('RDPApp', '1.0', 'Test DB', 2 * 1024 * 1024);
		self.upTimeHours = ko.observable();
		self.upTimeMinutes = ko.observable();
		self.upTimeNotes = ko.observable();
		self.idleTimeHours = ko.observable();
		self.idleTimeMinutes = ko.observable();
		self.idleTimeNotes = ko.observable();
		self.plannedOutageHrs = ko.observable();
		self.plannedOutageMinutes = ko.observable();
		self.plannedOutageNotes = ko.observable();
		self.unplannedOutageHrs = ko.observable();
		self.unplannedOutageMinutes = ko.observable();
		self.unplannedOutageNotes = ko.observable();
		self.dataLogNotes = ko.observable();
		self.gesnNo = ko.observable();
		self.firstName = ko.observable();
		self.lastName = ko.observable();
		self.pickedDateFromPopup = ko.observable();
		var todayDate = '';
		var todayDateThreeLetterMonthFormat = '';
		var todayDateToPost = '';
		var currentTime = '';
		var currentGesn = '';
		var upTimeHours;
		var upTimeMinutes;
		var upTimeNotes = '';
		var idleTimeHours;
		var idleTimeMinutes;
		var idleTimeNotes = '';
		var plannedOutageHrs;
		var plannedOutageMinutes;
		var plannedOutageNotes = '';
		var unplannedOutageHrs;
		var unplannedOutageMinutes;
		var unplannedOutageNotes = '';
		var dataLogNotes = '';
		var datalog = new Object();
		var pickedGesnNo;
		var pickedDate = '';
		var userProfile;
		self.init = function(gesn, userProfileFromAsset) {
			currentPageId = self.pageId;
			todayDateToPost = self.currDate();
			currentGesn = gesn;
			userProfile = userProfileFromAsset;
			self.firstName(userProfile.firstName);
			self.lastName(userProfile.lastName);
			self.gesnNo(currentGesn);
		};
		$("#allunits-datepickerP").datepicker({
			dateFormat : 'dd-M-yy',
			monthNamesShort : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
			onSelect : function(date12) {
				console.log(date12);
				var temp = date12;
				self.pickedDateFromPopup(temp);
				todayDateToPost = temp;
				// showLoader();
				// self.getDataForDatalogFromWebService();
				// $("#allunitstodate-datepicker").hide();
				// console.log(date);
			}
		});
		self.currDate = function() {
			var toDay = new Date();
			var currMonth = convertNoToMonth(toDay.getMonth());
			var cuurDay = ("0" + toDay.getDate()).slice(-2);
			todayDate = toDay.getDate() + " " + currMonth + " " + toDay.getFullYear();
			todayDateThreeLetterMonthFormat = cuurDay + "-" + currMonth.substring(0, 3) + "-" + toDay.getFullYear();
			console.log(todayDateThreeLetterMonthFormat);
			currentTime = toDay.getHours() + ":" + toDay.getMinutes() + ":" + toDay.getSeconds();
			return todayDateThreeLetterMonthFormat;
		};

		self.checkTime = function(hours, minutes) {
			var hoursNo = Number(hours);
			var minutesNo = Number(minutes);
			console.log(hoursNo);
			console.log(minutesNo);
			var temp1 = hoursNo * 10 / 10;
			var temp2 = minutesNo * 10 / 10;
			var hoursStg = String(temp1);
			var minuteStg = String(temp2);
			if (hours > 24 || hours < 0 || minutes < 0 || minutes > 59 || hours == undefined || minutes == undefined || hours != hoursStg || minutes != minuteStg || hours % 1 != 0 || minutes % 1 != 0)
				return false;
			else
				return true;
		};
		self.totalTimeValidation = function() {
			var totalTimeMinutes = ((upTimeHours * 60) + upTimeMinutes) + (idleTimeHours * 60) + idleTimeMinutes + (plannedOutageHrs * 60) + plannedOutageMinutes + (unplannedOutageHrs * 60) + unplannedOutageMinutes;
			totalTimeMinutes = totalTimeMinutes;
			var actualTime = 24 * 60;
			// console.log(totalTimeMinutes);
			// console.log(actualTime);
			if (totalTimeMinutes > actualTime)

				alert("Log Hours exceeds 24 hours");
			if (totalTimeMinutes < actualTime)

				alert("Log Hours less than 24 hours");
			if (totalTimeMinutes != actualTime)
				return false;
			else
				return true;
		};
		self.createDataLog = function() {
			$(".time-input-div input").css('background-color', '#EDEDED');
			upTimeHours = Number(self.upTimeHours());
			upTimeMinutes = Number(self.upTimeMinutes());
			upTimeNotes = self.upTimeNotes();
			idleTimeHours = Number(self.idleTimeHours());
			idleTimeMinutes = Number(self.idleTimeMinutes());
			idleTimeNotes = self.idleTimeNotes();
			plannedOutageHrs = Number(self.plannedOutageHrs());
			plannedOutageMinutes = Number(self.plannedOutageMinutes());
			plannedOutageNotes = self.plannedOutageNotes();
			unplannedOutageHrs = Number(self.unplannedOutageHrs());
			unplannedOutageMinutes = Number(self.unplannedOutageMinutes());
			unplannedOutageNotes = self.unplannedOutageNotes();
			dataLogNotes = self.dataLogNotes();
			// pickedGesnNo = autoFillGesn.val();
			// self.pickedGesnNo(pickedGesnNo);
			pickedGesnNo = currentGesn;
			pickedDate = todayDateToPost;

			if (self.checkTime(upTimeHours, upTimeMinutes)) {
				if (self.checkTime(idleTimeHours, idleTimeMinutes)) {
					if (self.checkTime(plannedOutageHrs, plannedOutageMinutes)) {
						if (self.checkTime(unplannedOutageHrs, unplannedOutageMinutes)) {
							if (self.totalTimeValidation()) {
								console.log("valid");
								self.postWebService();
							} else
								console.log("total should be 24hours");
						} else
							alert("Please enter valid data");
					} else
						alert("Please enter valid data");
				} else
					alert("Please enter valid data");
			} else
				alert("Please enter valid data");

			if (self.checkTime(upTimeHours, upTimeMinutes) == false) {
				$("#pop-uptimeHr").css('background-color', '#F1C5C5');
				$("#pop-uptimeMn").css('background-color', '#F1C5C5');
			}
			if (self.checkTime(idleTimeHours, idleTimeMinutes) == false) {
				$("#pop-idletimeHr").css('background-color', '#F1C5C5');
				$("#pop-idletimeMn").css('background-color', '#F1C5C5');
			}
			if (self.checkTime(plannedOutageHrs, plannedOutageMinutes) == false) {
				$("#pop-plannedHr").css('background-color', '#F1C5C5');
				$("#pop-plannedMn").css('background-color', '#F1C5C5');
			}
			if (self.checkTime(unplannedOutageHrs, unplannedOutageMinutes) == false) {
				$("#pop-unplannedHr").css('background-color', '#F1C5C5');
				$("#pop-unplannedMn").css('background-color', '#F1C5C5');
			}

			$(".time-input-div input").val('');
			$(".SubBoxHeadFNotes textarea").val('');
			$(".finalComment textarea").val('');
		};

		self.cancelDataLog = function() {
			$(".time-input-div input").val('');
			$(".SubBoxHeadFNotes textarea").val('');
			$(".finalComment textarea").val('');
			$(".time-input-div input").css('background-color', '#EDEDED');
			hideDataLogPopUp();
		};
		self.postWebService = function() {
			showLoader();
			datalog = ( {
				dataLog : {
					gesn : pickedGesnNo,
					logDate : pickedDate,
					// logDate : "31-Dec-2015",
					// systemTime : currentTime,
					upTimehours : upTimeHours,
					upTimeminutes : upTimeMinutes,
					upTimenotes : upTimeNotes,
					idleTimehours : idleTimeHours,
					idleTimeminutes : idleTimeMinutes,
					idleTimenotes : idleTimeNotes,
					plannedOutagehours : plannedOutageHrs,
					plannedOutageminutes : plannedOutageMinutes,
					plannedOutagenotes : plannedOutageNotes,
					unplannedOutagehours : unplannedOutageHrs,
					unplannedOutageminutes : unplannedOutageMinutes,
					unplannedOutagenotes : unplannedOutageNotes,
					dataLogNotes : dataLogNotes
				}
			});
			var jsonDatalog = JSON.stringify(datalog);
			console.log(datalog);
			console.log(jsonDatalog);
			xhr = $.ajax({
				type : "POST",
				url : webServiceURL_createDatalog,
				data : jsonDatalog,
				headers : {
					"Content-Type" : "application/json",
					"Accept" : "application/json"
				},
				// contentType : "application/json; charset=utf-8",
				// dataType : "json",
				success : function(data) {
					console.log(data);
					// hideLoader();
				},
				error : function(errMsg) {
					alert(errMsg);
					hideLoader();
				},
				complete : function(response) {
					console.log(response.responseText);
					console.log(response.status);
					if (response.status == 200 && response.readyState == 4) {
						alert(response.responseText);
					} else {
						alert("Please try after some time");
					}
					hideLoader();
					hideDataLogPopUp();
					$(".time-input-div input").val('');
					$(".SubBoxHeadFNotes textarea").val('');
					$(".finalComment textarea").val('');
					$(".time-input-div input").css('background-color', '#EDEDED');
				}
			});
			console.log(xhr);
			hideDataLogPopUp();
		};

	};
});
