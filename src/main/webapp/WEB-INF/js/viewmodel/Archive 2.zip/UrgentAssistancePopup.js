define(['knockout'], function(ko) {
	return function UrgentAssistancePopup() {
		var self = this;
		self.pageId = "UrgentAssistancePopup";
		var db = openDatabase('RDPApp', '1.0', 'Test DB', 2 * 1024 * 1024);
		var userProfile;
		var NotificationData;
		self.name = ko.observable();
		self.addEmail = ko.observable();
		self.contact = ko.observable();
		self.rmTeamIssueDesc = ko.observable();
		self.actionBySiteTeam = ko.observable();
		self.additionalInfo = ko.observable();

		var name = '';
		var addEmail = '';
		var contact = '';
		var rmTeamIssueDesc = '';
		var actionBySiteTeam = '';
		var additionalInfo = '';

		self.init = function(userProfileFromNotifications, dataFromNotifications) {
			currentPageId = self.pageId;
			userProfile = userProfileFromNotifications;
			NotificationData = dataFromNotifications;
			self.clickYesforDecRemote();
		};
		self.createUrgentAssistance = function() {
			$(".finalComment  textarea").val('');
			hideUrgentAssistancePopup();
			name = (self.name());
			addEmail = (self.addEmail());
			contact = (self.contact());
			rmTeamIssueDesc = (self.rmTeamIssueDesc());
			actionBySiteTeam = (self.actionBySiteTeam());
			additionalInfo = (self.additionalInfo());
			console.log(name);
			console.log(addEmail);
			console.log(contact);
			console.log(rmTeamIssueDesc);
			console.log(actionBySiteTeam);
			console.log(additionalInfo);

			if (self.validatetextareaforurgent(name)) {
				if (self.checkEmail(addEmail)) {
					if (self.phonenumber(contact)) {
						if(self.validatetextareaforurgent(rmTeamIssueDesc)){
						if (self.validatetextareaforurgent(actionBySiteTeam)) {
							if (self.validatetextareaforurgent(additionalInfo)) {
								console.log("valid field of feedback");
								self.postWebService2();
							} else
								alert("Field is not valid");
						} else
							alert("Field is not valid");
					} else
						alert("Field is not valid");
				} else
					alert("Field is not valid");
			} else
				alert("Field is not valid");
		  }
			else
				alert("Field is not valid");	
		};

		self.postWebService2 = function() {
			urgent = ( {
				sender : userProfile.email,
				title : NotificationData.title,
				engineSerial : NotificationData.engineSerial,
				organization : NotificationData.organization,
				name : name,
				addEmail : addEmail,
				contact : contact,
				issueStatus : null,
				rmTeamStatus : rmTeamStatus,
				rmTeamIssueDesc : rmTeamIssueDesc,
				actionBySiteTeam : actionBySiteTeam,
				additionalInfo : additionalInfo,
			});
			var jsonurgent = JSON.stringify(urgent);
			console.log(urgent);
			console.log(jsonurgent);
			showLoader();
			xhr = $.ajax({
				type : "POST",

				url : webServiceURL_uegent_mail,
				data : jsonurgent,
				headers : {
					"Content-Type" : "application/json",
					"Accept" : "application/json"
				},
				// contentType : "application/json; charset=utf-8",
				// dataType : "json",
				success : function(data) {
					console.log(data);
				},
				failure : function(errMsg) {
					alert(errMsg);
				},
				complete : function(response) {
					console.log(response.responseText);
					hideLoader();
					if (response.readyState == 4 || response.status == 200) {
						alert(response.responseText);
						hideUrgentAssistancePopup();
					}
				}
			});
			console.log(xhr);
		};

		self.clickYesforDecRemote = function() {
			console.log("clicked yes");
			$("#issueRadioYesforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioNoforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');
            $("#textenabledisable").attr('disabled','disabled'); 
             $("#textenabledisable").val('');
            // $("#textenabledisable").css('background-color', '#EDEDED'); 
			rmTeamStatus = "Yes";
		};
		self.clickNoforDecRemote = function() {
			console.log("clicked no");
			$("#issueRadioNoforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-selected.png")');
			$("#issueRadioYesforDecRemote").css('background-image', 'url("../img/Notification/X-redio-button-unselected.png")');
            $("#textenabledisable").removeAttr('disabled'); 
            $("#textenabledisable").val('');
           // $("#textenabledisable").css('background-color', '#EDEDED'); 
			rmTeamStatus = "No";

		};
		
		
		self.validatetextareaforurgent = function(textcommentforurgent) {
			
			if (textcommentforurgent == undefined || textcommentforurgent == '') {
				
				return false;
			} else {
				
				return true;
			}
		};

		self.cancelUrgentAssistance = function() {
			hideUrgentAssistancePopup();
			$(".name  input").val('');
			$(".email  input").val('');
			$(".phone  input").val('');
			$(".finalComment  textarea").val('');
			console.log("urgent");
		};
		
		
	 self.phonenumber = function(inputtxtcontact) {

	 	//var phoneno = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;

	 	var phoneno = /^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$/;
	 	if (!inputtxtcontact.value.match(phoneno)) {
	 		return false;
	 	} else {
	 		return true;
	 	}
	 };

		
		
		self.checkEmail = function(email) {

			var email = document.getElementById('txtEmail');
			var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

			if (!filter.test(email.value)) {

				email.focus;
				return false;
			} else
				return true;
		};
	};
});
